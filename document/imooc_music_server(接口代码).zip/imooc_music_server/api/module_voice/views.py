#!/usr/bin/env python
# -*- coding:utf-8 -*-

# 第三方库导入
from django.http import HttpResponse, JsonResponse, HttpRequest
# 本地代码库导入
from util.constant.httpconstant import *


# 发现页面接口
@allow_host
def home_recommand(request):
    if request.method == 'POST':
        # 报请求方法不对接口异常
        return JsonResponse(
            get_result(HTTP_INVALIDATE_METHOD_CODE, HTTP_INVALIDATE_METHOD_MSG, None))
    elif request.method == 'GET':
        response = JsonResponse(
            get_result(HTTP_SUCCESS_CODE, HTTP_SUCCESS_MSG, RESPONSE_HOME_RECOMMAND))
        return response


# 发现页面更多接口
@allow_host
def home_recommand_more(request):
    if request.method == 'POST':
        # 报请求方法不对接口异常
        return JsonResponse(
            get_result(HTTP_INVALIDATE_METHOD_CODE, HTTP_INVALIDATE_METHOD_MSG, None))
    elif request.method == 'GET':
        response = JsonResponse(
            get_result(HTTP_SUCCESS_CODE, HTTP_SUCCESS_MSG, RESPONSE_HOME_RECOMMAND_MORE))
        return response


# 朋友模块接口
@allow_host
def home_friend(request):
    if request.method == 'POST':
        # 报请求方法不对接口异常
        return JsonResponse(
            get_result(HTTP_INVALIDATE_METHOD_CODE, HTTP_INVALIDATE_METHOD_MSG, None))
    elif request.method == 'GET':
        response = JsonResponse(get_result(HTTP_SUCCESS_CODE, HTTP_SUCCESS_MSG, RESPONSE_FRIEND))
        return response


# 登录接口
@allow_host
def login_phone(request):
    if request.method == 'POST':
        # 报请求方法不对接口异常
        return JsonResponse(
            get_result(HTTP_INVALIDATE_METHOD_CODE, HTTP_INVALIDATE_METHOD_MSG, None))

    response = JsonResponse(get_result(HTTP_SUCCESS_CODE, HTTP_SUCCESS_MSG, RESPONSE_LOGIN))
    return response
