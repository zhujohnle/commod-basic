from django.urls import path
from . import views

urlpatterns = [
    path('home_recommand', views.home_recommand),
    path('home_recommand_more', views.home_recommand_more),
    path('home_friend', views.home_friend),
    path('login_phone', views.login_phone),
]
