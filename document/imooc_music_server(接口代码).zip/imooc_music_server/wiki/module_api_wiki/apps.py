from django.apps import AppConfig


class ModuleApiWikiConfig(AppConfig):
    name = 'module_api_wiki'
